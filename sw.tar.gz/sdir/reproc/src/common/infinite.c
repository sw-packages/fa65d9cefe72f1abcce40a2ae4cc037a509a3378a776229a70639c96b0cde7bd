#include <reproc/reproc.h>

// Same value as `INFINITE` on Windows.
const unsigned int REPROC_INFINITE = 0xFFFFFFFF;
